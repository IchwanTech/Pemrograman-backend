const coffes = [
  {
    id: 1,
    nama: "Cappucino",
    price: 20000,
  },
  {
    id: 2,
    nama: "Latte",
    price: 25000,
  },
  {
    id: 3,
    nama: "Espresso",
    price: 15000,
  },
  {
    id: 4,
    nama: "Americano",
    price: 20000,
  },
  {
    id: 5,
    nama: "Mocha",
    price: 25000,
  },
];

export default coffes;

let dataUser = [
  {
    id: 1,
    nama: "Ichwan Noerfitrah",
    email: "ichwan@gmail.com",
    password: "ichwan123",
  },
  {
    id: 2,
    nama: "Isro nbx",
    email: "isro@gmail.com",
    password: "isro123",
  },
  {
    id: 3,
    nama: "Faiz ramdhan",
    email: "faiz@gmail.com",
    password: "faiz123",
  },
  {
    id: 4,
    nama: "Rizky",
    email: "rizky@gmail.com",
    password: "rizky123",
  },
  {
    id: 5,
    nama: "Reza rahayu",
    email: "reza@gmail.com",
    password: "reza123",
  },
];

export default dataUser;
